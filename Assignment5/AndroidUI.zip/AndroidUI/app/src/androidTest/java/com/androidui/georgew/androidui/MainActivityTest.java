package com.androidui.georgew.androidui;

import static org.junit.Assert.*;

/**
 * Created by georgew on 5/9/17.
 */
public class MainActivityTest {

}