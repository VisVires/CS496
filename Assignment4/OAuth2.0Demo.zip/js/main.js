document.getElementById("auth_button").onclick = function(){changeWords()};
function changeWords() {
	document.getElementById("auth_button").innerHTML = "CLICKED IT!";
}
